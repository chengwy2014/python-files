# import mods
import pygame
import random
import sys
import math

# create window
pygame.init()
gamewindow = pygame.display.set_mode((800,600))
pygame.display.set_caption('飞机大战1.3.0')# set window title

# window icon
icon = pygame.image.load('ufo.png') # load ufo.png
pygame.display.set_icon(icon) # set icon to ufo.png
# load files
background = pygame.image.load('bg.png') # background




enemy = pygame.image.load('enemy.png') # enemy
p1_plane = pygame.image.load('player.png') # player plane
font = pygame.font.Font('freesansbold.ttf',32)

pygame.mixer.music.load("bg.wav")
pygame.mixer.music.play(-1)

bao_sound = pygame.mixer.Sound("exp.wav")
score = 0
def show_score():
    text = f'Score: {score}'

    score_render = font.render(text,True,(255,0,0))

    gamewindow.blit(score_render,(10,10))
is_over = False
over_font = pygame.font.Font('freesansbold.ttf',64)
def check_is_over():
    if is_over:
        text = "Game over"

        render = over_font.render(text,True,(255,0,0))

        gamewindow.blit(render,(200,500))


def distance(bx,by,ex,ey):
    a = bx - ex
    b = by - ey
    return math.sqrt(a*a + b*b)



# enemy cordinate



running = True
number_of_enemies = 6
class Enemy():
    def __init__(self):
        self.img = pygame.image.load('enemy.png')

        self.x = random.randint(200,600)
        self.y = random.randint(50,250)

        self.step = random.randint(2,4)

    def reset(self):
        self.x = random.randint(200,600)
        self.y = random .randint(50,200)

class Bullets():
    def __init__(self):
        self.img = pygame.image.load("bullet.png")
        self.x = p1_plane_x + 16 # (64-32)/2
        self.y = p1_plane_y + 10

        self.step = 10

    def hit(self):
        global score
        for e in enemies:
            if(distance(self.x,self.y,e.x,e.y) < 30):

                bao_sound.play()

                bullets.remove(self)
                e.reset()

                score += 1

bullets = []

def show_bullets():
    for b in bullets:
        gamewindow.blit(b.img,(b.x,b.y))
        b.hit()
        b.y -= b.step

        if b.y < 0:
            bullets.remove(b)


enemies = []
for i in range(number_of_enemies):
    enemies.append(Enemy())

def show_enemy():
    global is_over
    for e in enemies:
        gamewindow.blit(e.img,(e.x,e.y))
        e.x += e.step

        if(e.x > 736 or e.x < 0):

            e.step *= -1

            e.y += 40

            if e.y > 450:

                is_over = True
                enemies.clear()




p1_plane_x = 350
p1_plane_y = 450
playerStep = 0

def move_player():
    global p1_plane_x
    p1_plane_x += playerStep
    if p1_plane_x > 736:
        p1_plane_x = 736
    if p1_plane_x < 0:
        p1_plane_x = 0


while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            # if event.key == pygame.K_RIGHT:
            #     if p1_plane_x > 750:
            #         pass
            #     else:
            #         p1_plane_x=p1_plane_x+10
            # if event.key == pygame.K_LEFT:
            #     if p1_plane_x < 0:
            #         pass
            # else:
            #     p1_plane_x -= 5
            if event.key == pygame.K_RIGHT:
                playerStep = 5
            elif event.key == pygame.K_LEFT:
                playerStep = -5
            elif event.key == pygame.K_SPACE:
                bullets.append(Bullets())
    show_score()
    show_bullets()
    move_player()




    gamewindow.blit(background, (0, 0)) # backgroundw


    gamewindow.blit(p1_plane, (p1_plane_x, p1_plane_y))  # player_plane
    show_enemy()

    pygame.display.update()  # update window

pygame.quit()
sys.exit()